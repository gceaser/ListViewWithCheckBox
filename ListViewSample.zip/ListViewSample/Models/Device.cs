﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViewSample
{
    public class Device
    {
        public int ID { get; set; }
        public string DeviceName { get; set; }
        public string User { get; set; }
        public string LastTask { get; set; }
        public string ModelName { get; set; }
        public DateTime LastContact { get; set; }
        public string OSVersion { get; set; }
        public string Ownership { get; set; }
        public Boolean MDMProfileCurrent { get; set; }
        public string WarrantyInfo { get; set; }
        public string FreeSpace { get; set; }
        public bool Selected { get; set; }
        public List<string> Rooms { get; set; }
    }
}
