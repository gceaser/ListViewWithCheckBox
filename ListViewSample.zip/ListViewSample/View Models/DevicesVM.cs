﻿using System;
using System.Net;
using System.Collections.ObjectModel;
using System.ComponentModel;
//using Newtonsoft.Json;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using Windows.Web.Http;
using Windows.Web.Http.Headers;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace ListViewSample
{
    /// <summary>
    /// Class for the user metric view model
    /// </summary>
    public class DevicesVM : INotifyPropertyChanged
    {
        public ObservableCollection<Device> Devices { get; set; }

        private enum eCustomField
        {
            eRoom = 0,
            eSchedule = 1
        }

        public DevicesVM()
        {
            this.Devices = new ObservableCollection<Device>();
        }

        public int SelectedDeviceCount
        {
            get
            {
                if (Devices != null)
                {
                    return (from lobj_Device in Devices
                            where lobj_Device.Selected == true
                            select lobj_Device).Count();
                }
                else
                {
                    return 0;
                }
            }
        }

        public void DeviceSelectedInListView(int pi_DeviceID)
        {
            Device lobj_SelectedDevice;

            lobj_SelectedDevice = (from lobj_Device in Devices
                                   where lobj_Device.ID == pi_DeviceID
                                   select lobj_Device).ToList<Device>()[0];


            lobj_SelectedDevice.Selected = !lobj_SelectedDevice.Selected;
            NotifyPropertyChanged("Devices");
            SelectionsChanged();
        }

        public void SelectionsChanged()
        {
            NotifyPropertyChanged("SelectedDeviceCount");
        }
        public Boolean LoadData()
        {
            // Load some devices
            Devices.Add(new Device { ID = 1, DeviceName = "Device 1", User = "Test User 1", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership= "Test Owner", Rooms = null, Selected = false,  WarrantyInfo = null });
            Devices.Add(new Device { ID = 2, DeviceName = "Device 2", User = "Test User 2", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 3, DeviceName = "Device 3", User = "Test User 3", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 4, DeviceName = "Device 4", User = "Test User 4", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 5, DeviceName = "Device 5", User = "Test User 5", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 6, DeviceName = "Device 6", User = "Test User 6", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 7, DeviceName = "Device 7", User = "Test User 7", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 8, DeviceName = "Device 8", User = "Test User 8", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 9, DeviceName = "Device 9", User = "Test User 9", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 10, DeviceName = "Device 10", User = "Test User 10", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });
            Devices.Add(new Device { ID = 11, DeviceName = "Device 11", User = "Test User 11", FreeSpace = "1.4", LastContact = DateTime.MinValue, LastTask = null, MDMProfileCurrent = false, ModelName = "Test Model", OSVersion = "1.1", Ownership = "Test Owner", Rooms = null, Selected = false, WarrantyInfo = null });

            NotifyPropertyChanged("Devices");
            NotifyPropertyChanged("SelectedDeviceCount");

            return true;
        }
        


        public event PropertyChangedEventHandler PropertyChanged;

        // This method is called by the Set accessor of each property.
        // The CallerMemberName attribute that is applied to the optional propertyName
        // parameter causes the property name of the caller to be substituted as an argument.
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
